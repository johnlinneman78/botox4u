<?php
/**
 * CalmerPlaces Child Theme functions
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Enqueue parent (Astra) and child styles, plus Google Fonts.
 */
function calmerplaces_enqueue_styles() {
	// Astra parent stylesheet
	wp_enqueue_style(
		'astra-parent-style',
		get_template_directory_uri() . '/style.css',
		array(),
		wp_get_theme( 'astra' )->get( 'Version' )
	);

	// Child stylesheet (the CalmerPlaces design system)
	wp_enqueue_style(
		'calmerplaces-child-style',
		get_stylesheet_uri(),
		array( 'astra-parent-style' ),
		wp_get_theme()->get( 'Version' )
	);

	// Google Fonts: Instrument Serif + DM Sans
	wp_enqueue_style(
		'calmerplaces-fonts',
		'https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap',
		array(),
		null
	);
}
add_action( 'wp_enqueue_scripts', 'calmerplaces_enqueue_styles' );

/**
 * Preconnect to Google Fonts for performance.
 */
function calmerplaces_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = 'https://fonts.gstatic.com';
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'calmerplaces_resource_hints', 10, 2 );

/**
 * Helper: return live count of published GD places in a category slug.
 * Used by front-page.php to show real counts (or hide them at zero).
 *
 * NOTE: GeoDirectory's post type is typically 'gd_place' and the
 * category taxonomy is 'gd_placecategory'. Verify on this install.
 */
function calmerplaces_category_count( $slug ) {
	$term = get_term_by( 'slug', $slug, 'gd_placecategory' );
	if ( $term && ! is_wp_error( $term ) ) {
		return (int) $term->count;
	}
	return 0;
}

/**
 * Helper: total published places across the directory.
 */
function calmerplaces_total_places() {
	$counts = wp_count_posts( 'gd_place' );
	return isset( $counts->publish ) ? (int) $counts->publish : 0;
}
